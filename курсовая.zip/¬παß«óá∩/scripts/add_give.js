async function get_to_add_give () {

    const result = await fetch("http://localhost:3011/get.json")
    const add = await result.json()

    add.photo.push(document.getElementById("photo").value)
    add.address.push(document.getElementById("address").value)
    add.phone.push(Number(document.getElementById("phone").value))
    add.name.push(document.getElementById("name").value)
    add.rooms.push(Number(document.getElementById("rooms").value))
    add.square.push(Number(document.getElementById("square").value))
    add.description.push(document.getElementById("description").value)
    add.cost.push(Number(document.getElementById("cost").value))

    await fetch("http://localhost:3011/addhouse_give", {method: "POST", headers: {'Content-Type': "application/json"}, body: JSON.stringify(add) })
}

document.getElementById("save").addEventListener("click", get_to_add_give)