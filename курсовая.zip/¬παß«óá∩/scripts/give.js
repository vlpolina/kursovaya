async function to_give() {
    const result = await fetch("http://localhost:3011/give.json")
    const give = await result.json()

    let count = 0
    let cardItem2 = []

    let out = document.getElementById('out')

    for (let i = 0; i<give.name.length; i++) {
        cardItem2 +=
            `<br><div class="card">
                <br>
                <h3>${count+1}. Сниму квартиру: ${give.rooms[i]} комнат, площадь от ${give.square_ot[i]} до ${give.square_do[i]} м^2.</h3>
                <h4>Стоимость: от ${give.cost_ot[i]} до ${give.cost_do[i]} рублей.</h4>
                <h5>${give.region[i]}</h5><br>
                <p>${give.description[i]}</p><br>
                <div class="txt_card">
                    <p>Контактное лицо: ${give.name[i]}</p>
                    <p>Номер телефона: ${give.phone[i]}</p><br>
                </div>
                <br><br> <br><br> <br><br> <br>
            </div>
            <br>`
        count++
    }
    out.insertAdjacentHTML("afterbegin", cardItem2);
}

document.addEventListener("DOMContentLoaded", to_give)

document.getElementById("delete").addEventListener('click', async function() {
    const result = await fetch("http://localhost:3011/give.json")
    const del = await result.json()

    let numb = document.getElementById("del").value
    for (let i = 0; i<del.name.length; i++) {
        if (Number(numb-1) === i) {
            del.region.splice(i, 1)
            del.region.filter(n => n)
            del.phone.splice(i, 1)
            del.phone.filter(n => n)
            del.name.splice(i, 1)
            del.name.filter(n => n)
            del.rooms.splice(i, 1)
            del.rooms.filter(n => n)
            del.square_ot.splice(i, 1)
            del.square_ot.filter(n => n)
            del.square_do.splice(i, 1)
            del.square_do.filter(n => n)
            del.description.splice(i, 1)
            del.description.filter(n => n)
            del.cost_ot.splice(i, 1)
            del.cost_ot.filter(n => n)
            del.cost_do.splice(i, 1)
            del.cost_do.filter(n => n)
        }
    }
    await fetch("http://localhost:3011/addhouse_get", {method: "POST", headers: {'Content-Type': "application/json"}, body: JSON.stringify(del) })
    location.reload()
}, true);