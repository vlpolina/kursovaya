async function to_sell() {
    const result = await fetch("http://localhost:3011/sold.json")
    const sell = await result.json()

    let count = 0
    let cardItem3 = []

    let out = document.getElementById('out')

    for (let i = 0; i<sell.name.length; i++) {
        cardItem3 +=
            `<br><div class="card">
                <br>
                <h3>${count+1}. Куплю квартиру: ${sell.rooms[i]} комнат, площадь: от ${sell.square_ot[i]} до ${sell.square_do[i]} м^2.</h3>
                <h4>Цена: от ${sell.cost_ot[i]} до ${sell.cost_do[i]} рублей.</h4>
                <h5>${sell.region[i]}</h5><br>
                <p>${sell.description[i]}</p><br>
                <div class="txt_card">
                    <p>Контактное лицо: ${sell.name[i]}</p>
                    <p>Номер телефона: ${sell.phone[i]}</p><br>
                </div>
                <br><br> <br><br> <br><br> <br>
            </div>
            <br>`
        count++
    }
    out.insertAdjacentHTML("afterbegin", cardItem3);
}

document.addEventListener("DOMContentLoaded", to_sell)

document.getElementById("delete").addEventListener('click', async function() {
    const result = await fetch("http://localhost:3011/sold.json")
    const del = await result.json()

    let numb = document.getElementById("del").value
    for (let i = 0; i<del.name.length; i++) {
        if (Number(numb-1) === i) {
            del.region.splice(i, 1)
            del.region.filter(n => n)
            del.phone.splice(i, 1)
            del.phone.filter(n => n)
            del.name.splice(i, 1)
            del.name.filter(n => n)
            del.rooms.splice(i, 1)
            del.rooms.filter(n => n)
            del.square_ot.splice(i, 1)
            del.square_ot.filter(n => n)
            del.square_do.splice(i, 1)
            del.square_do.filter(n => n)
            del.description.splice(i, 1)
            del.description.filter(n => n)
            del.cost_ot.splice(i, 1)
            del.cost_ot.filter(n => n)
            del.cost_do.splice(i, 1)
            del.cost_do.filter(n => n)
        }
    }
    await fetch("http://localhost:3011/addhouse_buy", {method: "POST", headers: {'Content-Type': "application/json"}, body: JSON.stringify(del) })
    location.reload()
}, true);