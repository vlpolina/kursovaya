async function get_home() {
    const result = await fetch("http://localhost:3011/get.json")
    const get = await result.json()

    let count = 0;
    let cardItem1 = []

    let out = document.getElementById('out')

    for (let i = 0; i<get.name.length; i++) {
        cardItem1 +=
            `<br><div class="card">
                <br>
                <h3>${count+1}. Сдам квартиру: ${get.rooms[i]} комнат, площадь: ${get.square[i]} м^2.</h3>
                <h4>Цена: ${get.cost[i]} рублей.</h4>
                <h5>${get.address[i]}</h5><br>
                <img src="${get.photo[i]}" alt="фото помещения" class="photo"><br>
                <p>${get.description[i]}</p><br>
                <div class="txt_card">
                    <p>Контактное лицо: ${get.name[i]}</p>
                    <p>Номер телефона: ${get.phone[i]}</p><br>
                </div>
                <br><br> <br><br> <br><br> <br>
            </div>
            <br>`
        count++
    }
    out.insertAdjacentHTML("afterbegin", cardItem1);
}

document.addEventListener("DOMContentLoaded", get_home)

document.getElementById("delete").addEventListener('click', async function() {
    const result = await fetch("http://localhost:3011/get.json")
    const del = await result.json()

    let numb = document.getElementById("del").value
    for (let i = 0; i<del.name.length; i++) {
        if (Number(numb-1) === i) {
            del.photo.splice(i, 1)
            del.photo.filter(n => n)
            del.address.splice(i, 1)
            del.address.filter(n => n)
            del.phone.splice(i, 1)
            del.phone.filter(n => n)
            del.name.splice(i, 1)
            del.name.filter(n => n)
            del.rooms.splice(i, 1)
            del.rooms.filter(n => n)
            del.square.splice(i, 1)
            del.square.filter(n => n)
            del.description.splice(i, 1)
            del.description.filter(n => n)
            del.cost.splice(i, 1)
            del.cost.filter(n => n)
        }
    }
    await fetch("http://localhost:3011/addhouse_give", {method: "POST", headers: {'Content-Type': "application/json"}, body: JSON.stringify(del) })
    location.reload()
}, true);