async function getAdd() {
    const result = await fetch("http://localhost:3011/buy.json")
    const buy = await result.json()

    let count = 0
    let cardItem = []

    let out = document.getElementById('out')

    for (let i = 0; i<buy.name.length; i++) {
        cardItem +=
            `<br><div class="card">
                <br>
                <h3>${count+1}. Продам квартиру: ${buy.rooms[i]} комнат, площадь: ${buy.square[i]} м^2.</h3>
                <h4>Цена: ${buy.cost[i]} рублей.</h4>
                <h5>${buy.address[i]}</h5><br>
                <img src="${buy.photo[i]}" alt="фото помещения" class="photo"><br>
                <p>${buy.description[i]}</p><br>
                <div class="txt_card">
                    <p>Контактное лицо: ${buy.name[i]}</p>
                    <p>Номер телефона: ${buy.phone[i]}</p><br>
                </div>
                <br><br> <br><br> <br><br> <br>
            </div>
            <br>`
        count++
    }
    out.insertAdjacentHTML("afterbegin", cardItem);
}

document.addEventListener("DOMContentLoaded", getAdd)

document.getElementById("delete").addEventListener('click', async function() {
    const result = await fetch("http://localhost:3011/buy.json")
    const buy_del = await result.json()

    let numb = document.getElementById("del").value
    for (let i = 0; i<buy_del.name.length; i++) {
        if (Number(numb-1) === i) {
            buy_del.photo.splice(i, 1)
            buy_del.photo.filter(n => n)
            buy_del.address.splice(i, 1)
            buy_del.address.filter(n => n)
            buy_del.phone.splice(i, 1)
            buy_del.phone.filter(n => n)
            buy_del.name.splice(i, 1)
            buy_del.name.filter(n => n)
            buy_del.rooms.splice(i, 1)
            buy_del.rooms.filter(n => n)
            buy_del.square.splice(i, 1)
            buy_del.square.filter(n => n)
            buy_del.description.splice(i, 1)
            buy_del.description.filter(n => n)
            buy_del.cost.splice(i, 1)
            buy_del.cost.filter(n => n)
        }
    }
    await fetch("http://localhost:3011/addhouse", {method: "POST", headers: {'Content-Type': "application/json"}, body: JSON.stringify(buy_del) })
    location.reload()
}, true);

