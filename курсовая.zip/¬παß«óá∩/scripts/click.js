document.getElementById("add").addEventListener('click', function() {
    document.location.href = "../html/добавить.html";
}, true);
document.getElementById("buyhome").addEventListener('click', function() { 
    document.location.href = "../html/купить.html";
}, true);
document.getElementById("gethome").addEventListener('click', function() { 
    document.location.href = "../html/снять.html";
}, true);
document.getElementById("sellhome").addEventListener('click', function() { 
    document.location.href = "../html/продать.html";
}, true);
document.getElementById("givehome").addEventListener('click', function() { 
    document.location.href = "../html/сдать.html";
}, true);



