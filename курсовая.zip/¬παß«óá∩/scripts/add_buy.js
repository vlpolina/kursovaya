async function get_to_add_buy () {

    const result = await fetch("http://localhost:3011/sold.json")
    const add_buy = await result.json()

    add_buy.region.push(document.getElementById("region").value)
    add_buy.phone.push(document.getElementById("phone").value)
    add_buy.name.push(document.getElementById("name").value)
    add_buy.rooms.push(document.getElementById("rooms").value)
    add_buy.square_ot.push(document.getElementById("square_ot").value)
    add_buy.square_do.push(document.getElementById("square_do").value)
    add_buy.description.push(document.getElementById("description").value)
    add_buy.cost_ot.push(document.getElementById("cost_ot").value)
    add_buy.cost_do.push(document.getElementById("cost_do").value)

    await fetch("http://localhost:3011/addhouse_buy", {method: "POST", headers: {'Content-Type': "application/json"}, body: JSON.stringify(add_buy) })
}

document.getElementById("save").addEventListener("click", get_to_add_buy)