document.getElementById("add_buy").addEventListener('click', function() {
    document.location.href = "../html/добавить_купить.html";
}, true);
document.getElementById("add_get").addEventListener('click', function() {
    document.location.href = "../html/добавить_снять.html";
}, true);
document.getElementById("add_sell").addEventListener('click', function() {
    document.location.href = "../html/добавить_продать.html";
}, true);
document.getElementById("add_give").addEventListener('click', function() {
    document.location.href = "../html/добавить_сдать.html";
}, true);



