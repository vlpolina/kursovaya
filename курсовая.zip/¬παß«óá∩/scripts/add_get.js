async function get_to_add_get () {

    const result = await fetch("http://localhost:3011/give.json")
    const add = await result.json()

    add.region.push(document.getElementById("region").value)
    add.phone.push(document.getElementById("phone").value)
    add.name.push(document.getElementById("name").value)
    add.rooms.push(document.getElementById("rooms").value)
    add.square_ot.push(document.getElementById("square_ot").value)
    add.square_do.push(document.getElementById("square_do").value)
    add.description.push(document.getElementById("description").value)
    add.cost_ot.push(document.getElementById("cost_ot").value)
    add.cost_do.push(document.getElementById("cost_do").value)

    await fetch("http://localhost:3011/addhouse_get", {method: "POST", headers: {'Content-Type': "application/json"}, body: JSON.stringify(add) })
}

document.getElementById("save").addEventListener("click", get_to_add_get)
