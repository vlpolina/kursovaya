import express from 'express';
import cors from 'cors';
import * as fs from "fs";

const app = express()
const port = 3011

app.use(cors())

app.use(express.static('public'))

app.post("/addhouse", (req, res) => {
    req.on("data", (data) => {
        const obj = JSON.parse(String(data))
        let str = JSON.stringify(obj)

        fs.writeFile('C:\\Users\\Полина\\Documents\\ТПУ\\5 семестр\\web-программирование\\курсовая\\back\\public\\buy.json', str, (err) => {
            if (err) {
                console.error(err)
                return
            }
        })
        res.send("ok")
    })
})

app.post("/addhouse_buy", (reqq, ress) => {
    reqq.on("data", (data) => {
        const obj = JSON.parse(String(data))
        let str = JSON.stringify(obj)

        fs.writeFile('C:\\Users\\Полина\\Documents\\ТПУ\\5 семестр\\web-программирование\\курсовая\\back\\public\\sold.json', str, (err) => {
            if (err) {
                console.error(err)
                return
            }
        })
        ress.send("ok")
    })
})

app.post("/addhouse_give", (reqqq, resss) => {
    reqqq.on("data", (data) => {
        const obj = JSON.parse(String(data))
        let str = JSON.stringify(obj)

        fs.writeFile('C:\\Users\\Полина\\Documents\\ТПУ\\5 семестр\\web-программирование\\курсовая\\back\\public\\get.json', str, (err) => {
            if (err) {
                console.error(err)
                return
            }
        })
        resss.send("ok")
    })
})

app.post("/addhouse_get", (reqqqq, ressss) => {
    reqqqq.on("data", (data) => {
        const obj = JSON.parse(String(data))
        let str = JSON.stringify(obj)

        fs.writeFile('C:\\Users\\Полина\\Documents\\ТПУ\\5 семестр\\web-программирование\\курсовая\\back\\public\\give.json', str, (err) => {
            if (err) {
                console.error(err)
                return
            }
        })
        ressss.send("ok")
    })
})

app.listen(port, () => {
    console.log(`server listening on ${port}`)
})

